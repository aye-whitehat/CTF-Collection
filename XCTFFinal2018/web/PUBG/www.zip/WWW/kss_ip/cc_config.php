<?php  /*# Copyright(C) 2008-2018 www.hphu.com, All rights Reserved.  version:180119  KEY:ksreg20180115 */ ?><?php
//UTF-8无签名格式文件

define('NOTCCKG',0);

define('MAKEIMG',1);

define('MEMHOST','127.0.0.1');

define('MEMPORT',11211);

define('IPCOOKKEY','p8774ui6Vyi7bW15ZcKSMb85t3Li38V4');

define('IPCSTIME',36000);

define('IMGKEY','pVyi7bW15Z8774KSMb85t3ui6cLi38V4');

?>